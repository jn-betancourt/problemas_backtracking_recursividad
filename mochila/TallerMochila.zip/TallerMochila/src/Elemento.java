public class Elemento {
    private int peso;
    private int beneficio;
    private String nombre;

    public Elemento(int peso, int beneficio,String nombre) {
        this.peso = peso;
        this.beneficio = beneficio;
        this.nombre = nombre;
    }

    public int getPeso() {
        return peso;
    }

    public void setPeso(int peso) {
        this.peso = peso;
    }

    public int getBeneficio() {
        return beneficio;
    }

    public void setBeneficio(int beneficio) {
        this.beneficio = beneficio;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof Elemento)) {
            return false;
        }
        Elemento other = (Elemento) obj;
        return peso == other.peso && beneficio == other.beneficio;
    }

    @Override
    public String toString(){
        return "Nombre:" +nombre+","+ " Peso:"+peso+","+" beneficio:"+beneficio;
    }
}
