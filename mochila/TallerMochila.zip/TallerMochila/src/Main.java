public class Main {

    public static void main(String[] args) {
        Elemento [] elementos = {
            new Elemento (2,3,"Celular"),
            new Elemento(1,2,"Cargador"),
            new Elemento(5,10,"Ropa de playa"),
            new Elemento(4,3,"Zapatos"),
            new Elemento(10,1,"Peluche"),
        };

        Mochila m_base = new Mochila(15, elementos.length);
        Mochila m_opt = new Mochila(15, elementos.length);

        llenarMochila(m_base,elementos,false,m_opt);

        System.out.println(m_opt);
    }

    public static void llenarMochila(Mochila m_base, Elemento [] elementos,boolean llena, Mochila m_opt) {

        //si esta llena
        if (llena) {

            //compruebo si tiene mas beneficio que otra
            if (m_base.getBeneficio() > m_opt.getBeneficio()) {

                Elemento[] elementosMochBase = m_base.getElementos();
                m_opt.clear();

                //metemos los elementos
                for (Elemento elemento : elementosMochBase) {
                    if (elemento != null) {
                        m_opt.aniadirElemento(elemento);
                    }

                }

            }
        } else {
            // //Recorre los elementos
            for (int i = 0; i < elementos.length; i++) {

                //Si existe
                if(!m_base.existeElemento(elementos[i])) {

                    // //Si el peso de la mochila se supera, indicamos que esta llena
                    if(m_base.getPesoMaximo()>m_base.getPeso()+elementos[i].getPeso()) {
                        m_base.aniadirElemento(elementos[i]);
                        llenarMochila(m_base, elementos,false, m_opt);
                        m_base.eliminarElemento(elementos[i]);//Elimina el ultimo elemento añadido a m_base para explorar otras combinaciones
                    }else{
                        llenarMochila(m_base, elementos,true, m_opt);
                    }
                }
            }
        }
    }
}